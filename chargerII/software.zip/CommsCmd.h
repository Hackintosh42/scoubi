





#define CMD_GET_PACKINFO    0x50
#define CMD_GET_RECHARGENO  0x52
#define CMD_GET_TEMPERATURE 0x53
#define CMD_GET_OPTIME_MINS 0x54
#define CMD_GET_TIME        0x55
#define CMD_SET_TIME        0x56
#define CMD_INC_RECHARGECOUNT 0x59

#define CMD_SET_STARTTIME   0x20
#define CMD_GET_STARTTIME   0x21
#define CMD_SET_STOPTIME    0x22
#define CMD_GET_STOPTIME    0x23

#define CMD_SET_STARTSTOPTIME   0x24
#define CMD_GET_STARTSTOPTIME   0x25

#define CMD_UNKNOWN         0xBB
